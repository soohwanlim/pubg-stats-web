import cv2
import numpy as np
import os
import glob

class KillLogDetector:
    def __init__(self, template_dir='assets'):
        self.template_dir = template_dir
        self.event_templates = []
        self.number_templates = {}
        
        # [핵심 변경] 해상도별 Row Height 자동 설정
        # FHD(1080p) 기준: 23px
        self.row_height = 23 
        
        # 경로 문자열에 해상도가 포함되어 있는지 확인
        if '1440' in str(template_dir):
            self.row_height = 32  # QHD (약 1.33배)
            print(f"📐 [Detector] QHD 모드 감지됨 (Row Height: {self.row_height})")
        elif '2160' in str(template_dir):
            self.row_height = 46  # 4K (2배)
            print(f"📐 [Detector] 4K 모드 감지됨 (Row Height: {self.row_height})")
        else:
            print(f"📐 [Detector] FHD 모드 (Row Height: {self.row_height})")
        
        # 템플릿 로드
        self._load_templates()

    def _load_templates(self):
        print(f"📦 템플릿 로딩 중... ({os.path.basename(self.template_dir)})")
        
        # 1. 이벤트 아이콘 로드
        path = os.path.join(self.template_dir, 'events', '*.png')
        for f in glob.glob(path):
            name = os.path.splitext(os.path.basename(f))[0]
            if 'headshot' in name.lower(): continue
            
            img = cv2.imread(f, cv2.IMREAD_UNCHANGED)
            if img is None: continue
            
            if img.ndim == 3 and img.shape[2] == 4:
                gray = cv2.cvtColor(img[:, :, :3], cv2.COLOR_BGR2GRAY)
                mask = img[:, :, 3]
            else:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                mask = None
            self.event_templates.append((name, gray, mask))

        # 2. 숫자 템플릿 로드
        num_path = os.path.join(self.template_dir, 'numbers', '*.png')
        for f in glob.glob(num_path):
            name = os.path.splitext(os.path.basename(f))[0]
            img = cv2.imread(f, cv2.IMREAD_GRAYSCALE)
            if img is None: continue
            self.number_templates[name] = img

    def _match_number(self, img_roi):
        """이미지 영역에서 숫자(팀 번호)만 찾아서 반환"""
        if not self.number_templates or img_roi.size == 0: return "?"
        
        matches = []
        for digit, tmpl in self.number_templates.items():
            if tmpl.shape[0] > img_roi.shape[0] or tmpl.shape[1] > img_roi.shape[1]: continue
            
            res = cv2.matchTemplate(img_roi, tmpl, cv2.TM_CCOEFF_NORMED)
            loc = np.where(res >= 0.80) 
            
            for pt in zip(*loc[::-1]):
                matches.append({'x': pt[0], 'score': res[pt[1], pt[0]], 'digit': digit})
        
        if not matches: return "?"
        
        # X축 정렬 및 중복 제거
        matches.sort(key=lambda m: m['x'])
        final_digits = []
        if matches:
            curr = matches[0]
            for i in range(1, len(matches)):
                if matches[i]['x'] - curr['x'] < 5:
                    if matches[i]['score'] > curr['score']: curr = matches[i]
                else:
                    final_digits.append(curr)
                    curr = matches[i]
            final_digits.append(curr)
            
        return "".join([m['digit'] for m in final_digits])

    def detect(self, full_frame, roi_rect):
        rx, ry, rw, rh = roi_rect
        # ROI가 화면 밖으로 나가는 경우 방어
        if ry+rh > full_frame.shape[0] or rx+rw > full_frame.shape[1]: return []

        roi_img = full_frame[ry:ry+rh, rx:rx+rw]
        roi_gray = cv2.cvtColor(roi_img, cv2.COLOR_BGR2GRAY)
        logs = []
        
        # 1. 아이콘 찾기
        detected_icons = []
        for name, tmpl, mask in self.event_templates:
            # 템플릿 크기 체크 (방어 코드)
            if tmpl.shape[0] > roi_gray.shape[0] or tmpl.shape[1] > roi_gray.shape[1]:
                continue

            res = cv2.matchTemplate(roi_gray, tmpl, cv2.TM_CCOEFF_NORMED, mask=mask)
            threshold = 0.65
            loc = np.where(res >= threshold)
            
            for pt in zip(*loc[::-1]):
                is_duplicate = False
                for existing in detected_icons:
                    if abs(existing['y'] - pt[1]) < 10 and abs(existing['x'] - pt[0]) < 10:
                        is_duplicate = True; break
                if not is_duplicate:
                    detected_icons.append({'name': name, 'x': pt[0], 'y': pt[1], 'w': tmpl.shape[1]})
        
        detected_icons.sort(key=lambda d: d['y'])

        # 2. 각 아이콘 주변 팀 번호 읽기
        for icon in detected_icons:
            icon_x = icon['x']
            icon_y = icon['y']
            icon_w = icon['w']
            
            # 여기서 self.row_height가 해상도에 맞게 적용됨
            line_y1 = max(0, icon_y - 2)
            line_y2 = min(rh, icon_y + self.row_height + 2)
            
            # 왼쪽 (킬러 팀)
            left_area = roi_gray[line_y1:line_y2, 0:icon_x]
            k_num = self._match_number(left_area)
            
            # 오른쪽 (피해자 팀)
            right_area_start = icon_x + icon_w
            right_area = roi_gray[line_y1:line_y2, right_area_start:]
            v_num = self._match_number(right_area)
            
            lower_name = icon['name'].lower()
            is_knock = 'knock' in lower_name or 'groggy' in lower_name
            
            log_entry = {
                'type': 'knock' if is_knock else 'kill',
                'killer_team': k_num if k_num != "?" else "Suicide",
                'victim_team': v_num,
                'x': icon_x,
                'y': icon_y
            }
            logs.append(log_entry)
            
        return logs