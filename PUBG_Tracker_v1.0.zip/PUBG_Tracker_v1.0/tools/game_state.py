
import time

class GameState:
    def __init__(self):
        self.teams = {}
        self.TIME_TO_REVIVE = 8.0      
        self.MAX_BLEED_OUT = 110.0     
        self.MAX_KNOCKS = 3            
        
        # [설정] 1번 섹터 유지 시간 (초)
        self.SECTOR1_COOLDOWN = 5 * 60  # 5분
        
        self.game_start_time = None
        self.checked_17min = False
        self.pinned_team_id = None
        
        self.apply_settings(31, {})

    def apply_settings(self, total_teams, squad_sizes):
        self.teams = {}
        self.pinned_team_id = None
        for i in range(1, int(total_teams) + 1):
            tid = str(i)
            size = int(squad_sizes.get(tid, 4))
            self.teams[tid] = {
                'id': tid, 'alive': size, 'dead': 0, 'kills': 0, 'knocks': [],
                'sector': 3, 'max_size': size,
                'last_active': 0
            }

    def set_start_time(self, timestamp):
        self.game_start_time = timestamp
        self.checked_17min = False

    def _get_team(self, team_id):
        tid_lower = str(team_id).lower()
        if "suicide" in tid_lower or "bluezone" in tid_lower or team_id == "?": return None
        team_id = str(team_id)
        if team_id not in self.teams:
            self.teams[team_id] = {
                'id': team_id, 'alive': 4, 'dead': 0, 'kills': 0, 'knocks': [],
                'sector': 3, 'max_size': 4, 'last_active': 0
            }
        return self.teams[team_id]

    def delete_team(self, team_id):
        if team_id in self.teams:
            del self.teams[team_id]
            if self.pinned_team_id == team_id: self.pinned_team_id = None

    def toggle_pin(self, team_id):
        team_id = str(team_id)
        if self.pinned_team_id == team_id: self.pinned_team_id = None
        else: self.pinned_team_id = team_id

    def update_player_status(self, team_id, old_status, new_status):
        t = self.teams.get(team_id)
        if not t: return
        t['last_active'] = time.time()
        if old_status == new_status: return

        if old_status == 'alive':
            if t['alive'] > 0: t['alive'] -= 1
        elif old_status in ['knock', 'reviv']:
            if len(t['knocks']) > 0: t['knocks'].pop(0)
        elif old_status == 'dead':
            if t['dead'] > 0: t['dead'] -= 1

        if new_status == 'alive': t['alive'] += 1
        elif new_status == 'knock': t['knocks'].append({'time': time.time(), 'status': 'KNOCK'})
        elif new_status == 'dead': t['dead'] += 1

    def _force_wipe(self, team_data):
        if not team_data: return
        team_data['sector'] = 4
        team_data['alive'] = 0
        team_data['knocks'] = [] 
        team_data['dead'] = team_data['max_size']
        team_data['last_active'] = time.time()

    def check_rapid_wipe(self, new_logs):
        messages = []
        victim_counts = {}
        for log in new_logs:
            if log['type'] == 'kill':
                v_team = str(log['victim_team'])
                victim_counts[v_team] = victim_counts.get(v_team, 0) + 1
        
        for v_team, count in victim_counts.items():
            if count >= 2:
                team_data = self._get_team(v_team)
                if team_data:
                    if team_data['sector'] != 4:
                        self._force_wipe(team_data)
                        messages.append(f"⚡ [T{v_team}] 급가속 전멸({count}명 사망) -> 4번 섹터")
        return messages

    def process_event(self, log):
        now = time.time()
        k_str = str(log['killer_team'])
        v_str = str(log['victim_team'])
        event_type = log['type']
        
        v_data = self._get_team(v_str)
        k_data = self._get_team(k_str)
        
        messages = []

        if not v_data: return messages

        v_data['last_active'] = now
        if k_data: k_data['last_active'] = now

        if v_data['sector'] == 4:
            if event_type == 'kill' and k_data:
                k_data['kills'] += 1
                if k_data['sector'] == 3: k_data['sector'] = 1
            return messages 

        # 좀비 감지
        if k_data and k_data['alive'] == 0 and len(k_data['knocks']) == 0:
            k_data['dead'] = k_data['max_size'] - 1; k_data['alive'] = 1; k_data['sector'] = 2 
            messages.append(f"🧟 [T{k_str}] 좀비 감지 -> 2번 섹터")

        if event_type == 'knock':
            # ------------------------------------------------------------------
            # [요청사항 수정] "생존1 / 기절1~3" 상태에서 추가 기절은 무시
            # ------------------------------------------------------------------
            if v_data['alive'] == 1 and len(v_data['knocks']) >= 1:
                # 이미 기절한 팀원이 있는데, 마지막 남은 1명이 기절 로그가 떴다?
                # -> 보통 전멸(Kill 로그)이 뜨거나 해야 함. 
                # -> 따라서 이는 기존 기절자가 중복 인식된 것으로 간주하고 무시함.
                # messages.append(f"🛡️ [T{v_str}] 기절 중복 방어 (생존1 유지)")
                return messages

            # 블루칩 부활 감지
            if v_data['alive'] == 1 and v_data['dead'] > 0:
                v_data['dead'] -= 1
                messages.append(f"🧬 [T{v_str}] 블루칩 부활 감지")
            else:
                if v_data['alive'] > 0: v_data['alive'] -= 1
            
            v_data['knocks'].append({'time': now, 'status': 'KNOCK'})
            
            if len(v_data['knocks']) > self.MAX_KNOCKS:
                v_data['knocks'].pop(0); v_data['alive'] += 1
            messages.append(f"🔻 [T{v_str}] 기절!")
            
            if v_data['sector'] != 4: v_data['sector'] = 1
            if k_data and k_data['sector'] != 4: k_data['sector'] = 1

        elif event_type == 'kill':
            if k_data: k_data['kills'] += 1
            
            if len(v_data['knocks']) > 0:
                v_data['knocks'].pop(0); v_data['dead'] += 1
                messages.append(f"💀 [T{v_str}] 확킬!")
                if v_data['sector'] in [2, 3]: v_data['sector'] = 1
                if k_data and k_data['sector'] in [2, 3]: k_data['sector'] = 1
            else:
                if v_data['alive'] > 0: v_data['alive'] -= 1
                v_data['dead'] += 1
                
                if v_data['sector'] == 1:
                    self._force_wipe(v_data)
                    messages.append(f"💥 [T{v_str}] 1번 섹터 즉사 -> 4번(전멸)")
                else:
                    v_data['sector'] = 2 
                    if k_data and k_data['sector'] != 4: k_data['sector'] = 2
                    messages.append(f"🎯 [T{v_str}] 원거리 즉사 -> 2번 섹터")

        if v_data['dead'] >= v_data['max_size'] and v_data['sector'] != 4:
            self._force_wipe(v_data)
            messages.append(f"❌ [T{v_str}] 전멸 확정 -> 4번 섹터")

        return messages

    def update_timers(self):
        now = time.time()
        alerts = []
        
        if self.game_start_time and not self.checked_17min:
            elapsed_game = now - self.game_start_time
            if elapsed_game >= 17 * 60:
                self.checked_17min = True
                wiped_count = 0
                for tid in list(self.teams.keys()):
                    if tid in self.teams:
                        team = self.teams[tid]
                        if team['sector'] == 3:
                            self._force_wipe(team)
                            wiped_count += 1
                if wiped_count > 0: alerts.append(f"⏰ 17분 경과: 미발견 {wiped_count}팀 정리")

        for t_id, data in self.teams.items():
            if data['sector'] == 1:
                if (now - data['last_active']) > self.SECTOR1_COOLDOWN:
                    data['sector'] = 3

            for i in range(len(data['knocks']) - 1, -1, -1):
                k_info = data['knocks'][i]
                elapsed = now - k_info['time']
                if elapsed >= self.MAX_BLEED_OUT:
                    data['knocks'].pop(i); data['alive'] += 1
                    alerts.append(f"❤️ [T{t_id}] 자연 회복")
                elif elapsed >= self.TIME_TO_REVIVE and k_info['status'] == 'KNOCK':
                    k_info['status'] = 'REVIVABLE'
        return alerts
