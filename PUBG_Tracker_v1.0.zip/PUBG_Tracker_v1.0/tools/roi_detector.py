import cv2
import numpy as np
import os
import glob

EVENT_TEMPLATES = []
NUMBER_TEMPLATES = {}
CURRENT_PATH = None

def load_templates(asset_path):
    global EVENT_TEMPLATES, NUMBER_TEMPLATES, CURRENT_PATH
    if CURRENT_PATH == asset_path and EVENT_TEMPLATES: return

    CURRENT_PATH = asset_path
    EVENT_TEMPLATES = []
    NUMBER_TEMPLATES = {}
    
    print(f"📂 [ROI] 템플릿 로드: {os.path.basename(asset_path)}")
    
    path = os.path.join(asset_path, 'events', '*.png')
    for f in glob.glob(path):
        name = os.path.splitext(os.path.basename(f))[0]
        if 'headshot' in name.lower(): continue
        img = cv2.imread(f, cv2.IMREAD_UNCHANGED)
        if img is None: continue
        if img.ndim == 3 and img.shape[2] == 4:
            gray = cv2.cvtColor(img[:, :, :3], cv2.COLOR_BGR2GRAY)
            mask = img[:, :, 3]
        else:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            mask = None
        EVENT_TEMPLATES.append((name, gray, mask))

    path = os.path.join(asset_path, 'numbers', '*.png')
    for f in glob.glob(path):
        name = os.path.splitext(os.path.basename(f))[0]
        img = cv2.imread(f, cv2.IMREAD_GRAYSCALE)
        if img is None: continue
        NUMBER_TEMPLATES[name] = img

def find_number(img_gray, icon_x, icon_y, icon_w):
    if not NUMBER_TEMPLATES: return None
    roi_x1 = icon_x + icon_w
    roi_x2 = min(img_gray.shape[1], roi_x1 + 500)
    roi_y1 = max(0, icon_y - 5)
    roi_y2 = min(img_gray.shape[0], icon_y + icon_w + 5)
    search = img_gray[roi_y1:roi_y2, roi_x1:roi_x2]
    if search.size == 0: return None

    matches = []
    for digit, tmpl in NUMBER_TEMPLATES.items():
        if tmpl.shape[0] > search.shape[0] or tmpl.shape[1] > search.shape[1]: continue
        res = cv2.matchTemplate(search, tmpl, cv2.TM_CCOEFF_NORMED)
        loc = np.where(res >= 0.70)
        for pt in zip(*loc[::-1]):
            matches.append({'x': pt[0] + roi_x1, 'y': pt[1] + roi_y1, 'w': tmpl.shape[1]})
    
    if not matches: return None
    matches.sort(key=lambda m: m['x'])
    last = matches[-1]
    return last['x'] + last['w'], last['y']

def calculate_auto_roi(image_path, asset_path, debug_save_path=None):
    load_templates(asset_path)
    
    full_img = cv2.imread(image_path)
    if full_img is None: return None

    h, w = full_img.shape[:2]
    gray = cv2.cvtColor(full_img, cv2.COLOR_BGR2GRAY)
    roi_w = int(w * 0.25)
    search_gray = gray[:, int(w*0.5):]
    offset_x = int(w*0.5)
    
    logs = []
    for name, tmpl, mask in EVENT_TEMPLATES:
        if tmpl.shape[0] > search_gray.shape[0]: continue
        res = cv2.matchTemplate(search_gray, tmpl, cv2.TM_CCOEFF_NORMED, mask=mask)
        loc = np.where(res >= 0.6)
        for pt in zip(*loc[::-1]):
            abs_x = pt[0] + offset_x
            abs_y = pt[1]
            num_res = find_number(gray, abs_x, abs_y, tmpl.shape[1])
            if num_res:
                dup = False
                for exist in logs:
                    if abs(exist[0] - abs_y) < 10: dup = True; break
                if not dup: logs.append((abs_y, num_res[0]))

    logs.sort(key=lambda x: x[0])
    if len(logs) < 2: 
        if debug_save_path: cv2.imwrite(debug_save_path, full_img)
        return None
        
    y1 = logs[0][0]; y2 = logs[1][0]
    x_max = max(logs[0][1], logs[1][1]) + 10
    gap = y2 - y1
    roi_h = gap * 12
    roi_x = max(0, x_max - roi_w)
    roi_y = int(max(0, y1 - (gap * 0.5)))
    
    if debug_save_path:
        debug = full_img.copy()
        cv2.rectangle(debug, (roi_x, roi_y), (roi_x+roi_w, roi_y+roi_h), (0,255,0), 3)
        cv2.imwrite(debug_save_path, debug)
        
    return roi_x, roi_y, roi_w, roi_h