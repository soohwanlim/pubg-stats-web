import time

class KillLogTracker:
    def __init__(self):
        # 추적 중인 로그 리스트
        self.tracks = []
        
        # [설정]
        self.MARGIN_X = 5        # X좌표 허용 오차
        self.MAX_JUMP_Y = 200    # Y좌표 이동 허용 (스크롤)
        
        # [핵심] 킬 로그 수명 (초)
        # 한번 인식되면, 화면에서 사라져도 이 시간 동안은 '살아있는 것'으로 간주합니다.
        # 배그 킬 로그 유지 시간이 약 6초이므로, 중간에 4초간 인식이 안 돼도 기억합니다.
        self.ZOMBIE_DURATION = 6.0 

    def process_logs(self, current_logs):
        now = time.time()
        new_events = []
        
        # 이번 프레임에서 매칭된 트랙들 표시
        matched_track_indices = set()
        
        # 1. 현재 발견된 로그들을 기존 트랙과 매칭
        for curr in current_logs:
            best_match_idx = -1
            min_dist_y = 9999
            
            for idx, track in enumerate(self.tracks):
                if idx in matched_track_indices: continue
                
                prev = track['data']
                
                # A. 내용 비교 (팀 번호 + 타입)
                # 내용이 다르면 절대 같은 로그가 아님
                if (curr['killer_team'] != prev['killer_team'] or
                    curr['victim_team'] != prev['victim_team'] or
                    curr['type'] != prev['type']):
                    continue
                
                # B. X 좌표 비교 (좌우는 거의 고정)
                if abs(curr['x'] - prev['x']) > self.MARGIN_X:
                    continue
                
                # C. Y 좌표 비교 (아래로만 이동)
                # dy = 현재Y - 과거Y
                dy = curr['y'] - prev['y']
                
                # 위로 50px 이상 튀거나, 아래로 200px 이상 튀면 다른 것으로 간주
                # (단, -10 정도의 미세한 위쪽 떨림은 허용)
                if -10 <= dy < self.MAX_JUMP_Y:
                    if abs(dy) < min_dist_y:
                        min_dist_y = abs(dy)
                        best_match_idx = idx
            
            # 매칭 결과 처리
            if best_match_idx != -1:
                # [매칭 성공] -> "살아있었구나!"
                # 좌표와 마지막 목격 시간 갱신
                self.tracks[best_match_idx]['data'] = curr
                self.tracks[best_match_idx]['x'] = curr['x']
                self.tracks[best_match_idx]['y'] = curr['y']
                self.tracks[best_match_idx]['last_seen'] = now
                matched_track_indices.add(best_match_idx)
            else:
                # [매칭 실패] -> 6초 동안 본 적 없는 놈이면 "진짜 신규!"
                new_events.append(curr)
                self.tracks.append({
                    'data': curr,
                    'x': curr['x'],
                    'y': curr['y'],
                    'last_seen': now
                })

        # 2. 트랙 관리 (좀비 정리)
        # 마지막으로 본 지 6초가 지난 트랙만 삭제합니다.
        # 즉, 4초 동안 인식이 안 되다가 5초째에 다시 보여도 "아까 그놈"으로 인식합니다.
        self.tracks = [
            t for t in self.tracks 
            if now - t['last_seen'] < self.ZOMBIE_DURATION
        ]
        
        return new_events