import os
import ctypes
import logging

def get_screen_resolution():
    """현재 모니터 해상도(DPI 보정 포함) 반환"""
    try:
        user32 = ctypes.windll.user32
        user32.SetProcessDPIAware()
        return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    except Exception as e:
        logging.error(f"해상도 감지 실패: {e}")
        return 1920, 1080

# [수정됨] 함수 이름을 local_app.py가 찾는 'get_asset_path'로 통일
def get_asset_path(base_dir, mode='AUTO'):
    """
    mode: 'AUTO', '1080', '1440', '2160'
    """
    assets_root = os.path.join(base_dir, 'assets')
    target_folder = '1080'
    
    # 1. 수동 모드
    if mode != 'AUTO':
        if mode in ['1080', '1440', '2160']: target_folder = mode
        else: logging.warning(f"잘못된 모드({mode}), 기본값 사용")
    
    # 2. 자동 감지
    else:
        width, _ = get_screen_resolution()
        if width >= 3840: target_folder = '2160'
        elif width >= 2560: target_folder = '1440'
        else: target_folder = '1080'
        logging.info(f"🖥️ 해상도 자동 감지: {width}px -> {target_folder}p")

    final_path = os.path.join(assets_root, target_folder)

    # 폴더 없으면 안전책 (1080)
    if not os.path.exists(final_path):
        logging.warning(f"⚠️ {target_folder} 폴더 없음. 1080 폴더 사용.")
        fallback = os.path.join(assets_root, '1080')
        return fallback if os.path.exists(fallback) else assets_root
        
    return final_path